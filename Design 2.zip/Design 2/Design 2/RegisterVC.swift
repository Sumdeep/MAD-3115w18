//
//  RegisterVC.swift
//  Design 2
//
//  Created by MacStudent on 2018-02-22.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class RegisterVC: UIViewController,UIPickerViewDelegate, UIPickerViewDataSource {
    

    @IBOutlet weak var txtName: UITextField!
    
    @IBOutlet weak var txtNumber: UITextField!
    
    @IBOutlet weak var txtDate: UIDatePicker!
    
    @IBOutlet weak var txtCity: UIPickerView!
    
    @IBOutlet weak var txtEmail: UITextField!
    
    @IBOutlet weak var txtPassword: UITextField!
    
    
    @IBOutlet weak var txtPostalcode: UITextField!
    var cityList: [String] = ["Vancouver","Ottawa","Toronto","Calgary","Windsor","Ajax","Pickering","admenton","Alberta","British Columbia"]
    
    var selectedCityIndex: Int = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        self.txtCity.delegate = self
        self.txtCity.datasource = self
    }

func numberOfComponents(in pickerView: UIPickerView) -> Int {
    return 1
}
func pickerView(_pickerView: UIPickerView,numberOfRowsInComponent component: Int)
    -> Int {
        return self.cityList.count
}

func pickerView(_pickerView: UIPickerView,titleForRow row: Int, forComponent component: Int) -> String? {
    return self.cityList[row]
}



}
